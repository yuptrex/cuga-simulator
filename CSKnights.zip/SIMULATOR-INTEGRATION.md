# Simulator integration

The game has **no login screen**. It uses the account the simulator is already logged into.
Ranks, stats, leaderboard and saved button layout are stored in Firebase under that account's `uid`.
Graphics default to **ULTRA HD** for every new player.

## How the simulator passes the account (any one method)
1. `window.SIM_USER = {uid, name, photo, token}` injected before the page loads
2. URL: `index.html?uid=UID&name=NAME&photo=URL&token=CUSTOM_TOKEN`
3. Native WebView bridge: `window.SimulatorBridge.getUser()` returning an object or JSON string
4. iframe/opener: `window.postMessage({type:'sim-user', user:{uid,name,photo,token}}, '*')`
   (the game asks first with `{type:'csk-request-user'}`)
5. Existing Firebase Auth session (same origin + same Firebase project)

`uid` is required. `name` becomes the in-game name. `token` is optional (see below).

## Firebase rules
Existing rules require `auth != null` and `auth.uid === $uid`. To satisfy them the simulator should
send a Firebase **custom token** for the same uid (`token`); the game then signs in with it.
If the simulator uses the same Firebase project and origin, method 6 works with no token.
Without a token the game still runs, but saves only succeed if your rules allow that uid.

## Changed files
New: `sim-bridge.js` · Edited: `game.js`, `index.html`, `boot-gate.js`, `lock.js`, `lobby.js`, `battle-fx.js`, `asset-cache.js`
Removed: login screen, `login.js`, `login.css` and the login/setup images.

## Always the current account
The game never reuses a remembered account. On every launch, and every time it returns to the screen,
it asks the simulator who is logged in now. If the uid differs from the one it is running with, it
reloads and switches to the new account (the old account's cached stats are discarded).
Keep passing the account in the URL/`SIM_USER` on every launch.

## mode.txt
`mode.txt` contains one word, `landscape` or `portrait`, so the simulator knows how to orient the game.
This game is `landscape`.

## Name = simulator nickname
The in-game name is the nickname set in the simulator, never the Gmail/Google name. Send it as `nickname`
(`nick`, `username`, `name` also accepted, in that priority). If the nickname changes, the game reloads with the new one.

## How the Android simulator passes the account (CugaSimulator)
`GamePlayerActivity.kt` now reads the simulator profile (`UserProfileStore`) on every launch and gives the game
`uid`, `nickname` (the simulator nickname, never the Gmail name) and `photo`, both as `window.SIM_USER`
(document-start script) and as `?uid=&nickname=&photo=` on the game address (so Reload keeps it).

## Firebase (one-time, in the game's project `cloud-3eacc`)
The simulator signs in to a different Firebase project (`catcity-1d6fd`), so its login cannot sign in to the game's
project. The game therefore uses an anonymous Firebase session for database access, and stores everything under the
simulator `uid`:
1. Firebase console > `cloud-3eacc` > Authentication > Sign-in method > enable **Anonymous**.
2. Realtime Database > Rules: publish `database.rules.simulator.json`.
Note: data is keyed by the simulator uid, but the rules can only require "signed in", not "this exact user".

## Account link (v5)
- The account is taken the moment the page starts; it does NOT wait for Firebase. Name, local saves and the game are
  usable immediately, even offline. Firebase connects in the background (retries until it works).
- A brand-new account, or an existing Cuga account opening CSKnights for the first time, is created automatically:
  `users/<uid>/stats`, `profile`, `link {app, nick, seen, first}` and `leaderboard/<uid>`.
- Diagnostics: tap the account chip (top-left) 5 times to see source / uid / nickname / Firebase state.
- The simulator sends the account three ways: injected `window.SIM_USER`, URL params, and a postMessage after the page loads.
- IMPORTANT: the simulator only installs a game once. After uploading a new zip you must raise `version` in Firebase
  (`games/<id>/version`) or uninstall/reinstall the game, otherwise the phone keeps running the OLD files.
