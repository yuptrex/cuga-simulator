# Simulator integration

The game has **no login screen**. It uses the account the simulator is already logged into.
Ranks, stats, leaderboard and saved button layout are stored in Firebase under that account's `uid`.
Graphics default to **ULTRA HD** for every new player.

## How the simulator passes the account (any one method)
1. `window.SIM_USER = {uid, name, photo, token}` injected before the page loads
2. URL: `index.html?uid=UID&name=NAME&photo=URL&token=CUSTOM_TOKEN`
3. Native WebView bridge: `window.SimulatorBridge.getUser()` returning an object or JSON string
4. iframe/opener: `window.postMessage({type:'sim-user', user:{uid,name,photo,token}}, '*')`
   (the game asks first with `{type:'csk-request-user'}`)
5. `localStorage['sim-user']` (same origin)
6. Existing Firebase Auth session (same origin + same Firebase project)

`uid` is required. `name` becomes the in-game name. `token` is optional (see below).

## Firebase rules
Existing rules require `auth != null` and `auth.uid === $uid`. To satisfy them the simulator should
send a Firebase **custom token** for the same uid (`token`); the game then signs in with it.
If the simulator uses the same Firebase project and origin, method 6 works with no token.
Without a token the game still runs, but saves only succeed if your rules allow that uid.

## Changed files
New: `sim-bridge.js` · Edited: `game.js`, `index.html`, `boot-gate.js`, `lock.js`, `lobby.js`, `battle-fx.js`, `asset-cache.js`
Removed: login screen, `login.js`, `login.css` and the login/setup images.
