/* adaptive resolution - SHARPNESS FIRST. The canvas stays at full sharpness (up to 1.75x the screen's pixel ratio) and only steps down
   when the frame rate is really poor (clearly under the device's best), and never below ~1.4 canvas pixels per CSS pixel, so text and art
   stay crisp. It climbs back up quickly once there is headroom. Small stutters never lower the resolution. */
(function(){let ema=1/60,ref=1/50,slow=0,fast=0,lastCh=0,hold=4,lastUp=-1e9;
const base=()=>Math.min(window.devicePixelRatio||1,1.75);
const floor=()=>{const b=base();return b>1.4?Math.max(.5,1.4/b):1};   /* 1.75x -> 1.4x at the very lowest (rScale .8) */
window.AQ=function(dt,now){if(!(dt>0)||dt>.25||document.hidden)return;
 const MIN=floor();
 ema+=(dt-ema)*.06;if(ema<ref)ref=Math.max(1/165,ema);else ref+=(ema-ref)*.0002;
 if(ema>ref*1.6){slow+=dt;fast=0}else if(ema<ref*1.15){fast+=dt;slow=Math.max(0,slow-dt)}else{slow=Math.max(0,slow-dt*.5);fast=Math.max(0,fast-dt*.5)}
 if(slow>1.5&&rScale>MIN+.001&&now-lastCh>2500){
  if(now-lastUp<8000)hold=Math.min(40,hold*2);
  rScale=Math.max(MIN,rScale-.1);lastCh=now;slow=0;rs()}
 else if(fast>hold&&rScale<.999&&now-lastCh>2000){rScale=Math.min(1,rScale+.1);lastCh=now;lastUp=now;fast=0;rs()}}})();
