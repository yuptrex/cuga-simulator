/* adaptive resolution: if frames run slower than the screen's refresh rate, lower the render scale, and creep back up when
   there is headroom. FLOOR: the canvas never drops below ~1 pixel per CSS pixel (phones: 1.75x -> 1.0x), so text and art stay
   readable; with enough speed it sits at full sharpness (up to 1.75x the screen's pixel ratio). A very slow frame rate
   (under half of the device's best) drops two steps at once, so a heavy scene recovers in about a second instead of ten. */
(function(){let ema=1/60,ref=1/50,slow=0,fast=0,lastCh=0,hold=10,lastUp=-1e9;
const base=()=>Math.min(window.devicePixelRatio||1,1.75);
const floor=()=>{const b=base();return b>1.2?Math.max(.5,1/b):.75};
window.AQ=function(dt,now){if(!(dt>0)||dt>.25||document.hidden)return;
 const MIN=floor();
 ema+=(dt-ema)*.06;if(ema<ref)ref=Math.max(1/165,ema);else ref+=(ema-ref)*.0002;
 if(ema>ref*1.22){slow+=dt;fast=0}else if(ema<ref*1.07){fast+=dt;slow=Math.max(0,slow-dt)}else{slow=Math.max(0,slow-dt*.5);fast=Math.max(0,fast-dt*.5)}
 const bad=ema>ref*2;                                   /* running at under half of the best speed seen on this device */
 if(slow>(bad?.35:(window.CSK_LOWDEV?.8:1.2))&&rScale>MIN+.001&&now-lastCh>(bad?700:2000)){
  if(now-lastUp<5000)hold=Math.min(80,hold*2);
  rScale=Math.max(MIN,rScale-(bad?.25:.125));lastCh=now;slow=0;rs()}
 else if(fast>hold&&rScale<.999&&now-lastCh>2000){rScale=Math.min(1,rScale+.125);lastCh=now;lastUp=now;fast=0;rs()}}
/* touch phones with a dense screen start at 0.75 (about 1.3x) instead of spending the first seconds slow; it climbs on its own when there is headroom */
try{if(window.matchMedia&&matchMedia('(pointer:coarse)').matches&&base()>1.5&&typeof rScale!=='undefined'&&rScale>.75){rScale=.75;rs()}}catch(e){}
})();
