/* Full-screen button + auto full-screen on Play Solo / Create Room / Join.
   Self-contained: touches no game state. Browsers only allow full screen from
   inside a real tap/click, so the request is made synchronously in the click
   handler of each button (capture phase = before the game's own handler runs). */
(function(){
  var de=document.documentElement;
  var req=de.requestFullscreen||de.webkitRequestFullscreen||de.msRequestFullscreen;
  var ext=document.exitFullscreen||document.webkitExitFullscreen||document.msExitFullscreen;
  var btn=document.getElementById('fsb');

  function isFs(){return !!(document.fullscreenElement||document.webkitFullscreenElement||document.msFullscreenElement)}

  /* browser can't do it (e.g. iPhone Safari): hide the button, nothing else to do */
  if(!req){ if(btn) btn.hidden=true; return; }

  var allowed=!!window.CSK_AUTHED;   /* no full screen on sign-in / sign-up: only after a successful login */
  function enter(){
    if(!allowed||isFs()) return;
    try{
      var p=req.call(de);
      var coarse=window.matchMedia&&window.matchMedia('(pointer:coarse)').matches;
      if(p&&p.then){
        p.then(function(){
          /* on phones, also lock to landscape once full screen is on (ignored where unsupported) */
          if(coarse&&screen.orientation&&screen.orientation.lock){
            try{ screen.orientation.lock('landscape').catch(function(){}); }catch(e){}
          }
        }).catch(function(){});
      }
    }catch(e){}
  }
  function leave(){
    try{ var p=ext&&ext.call(document); if(p&&p.catch) p.catch(function(){}); }catch(e){}
  }

  /* The whole game runs full screen. Rules:
     - it goes full screen on the player's first tap/click/key after the page opens (browsers refuse without one),
     - the game itself NEVER leaves full screen; only the player can (button or Esc),
     - once the player has turned it off it stays off (remembered for this session, so Back to Home's page reload
       does not force it back on); pressing the full-screen button turns it on again. */
  var KEY='csk-fs-off',unloading=false;
  function userOff(){try{return sessionStorage.getItem(KEY)==='1'}catch(e){return false}}
  function setOff(v){try{v?sessionStorage.setItem(KEY,'1'):sessionStorage.removeItem(KEY)}catch(e){}}
  window.addEventListener('beforeunload',function(){unloading=true});
  window.addEventListener('pagehide',function(){unloading=true});
  ['fullscreenchange','webkitfullscreenchange','MSFullscreenChange'].forEach(function(n){
    document.addEventListener(n,function(){
      if(unloading) return;               /* page reload also drops full screen: that is not the player choosing */
      setOff(!isFs());
    });
  });
  var GEST=['pointerup','mouseup','touchend','click','keydown'];
  function onGesture(e){
    if(!allowed) return;
    if(e&&e.type==='keydown'&&e.key==='Escape') return;
    if(isFs()||userOff()){ if(isFs()) stopGest(); return; }
    enter();
  }
  function stopGest(){GEST.forEach(function(n){document.removeEventListener(n,onGesture,true)})}
  GEST.forEach(function(n){document.addEventListener(n,onGesture,true)});
  if(!userOff()) enter();                  /* works if the browser still allows it (e.g. after a tap on the previous page) */
  ['fullscreenchange','webkitfullscreenchange','MSFullscreenChange'].forEach(function(n){
    document.addEventListener(n,function(){
      /* if full screen was dropped (player pressed Esc), start listening again so a later button press can re-enter */
      if(!isFs()) GEST.forEach(function(g){document.addEventListener(g,onGesture,true)});
    });
  });

  function sync(){
    if(!btn) return;
    var on=isFs();
    btn.classList.toggle('on',on);
    btn.setAttribute('aria-pressed',on?'true':'false');
    var t=on?'Exit full screen':'Enter full screen';
    btn.setAttribute('aria-label',t); btn.title=t;
  }
  ['fullscreenchange','webkitfullscreenchange','MSFullscreenChange'].forEach(function(n){
    document.addEventListener(n,sync);
  });
  sync();

  if(btn) btn.addEventListener('click',function(e){ e.stopPropagation(); if(isFs()){ setOff(true); leave(); } else { setOff(false); enter(); } },true);

  /* auto full screen when a game/room is started from home */
  function hook(id,ok){
    var el=document.getElementById(id); if(!el) return;
    el.addEventListener('click',function(){ if(!ok||ok(el)) enter(); },true);
  }
  hook('solo');
  /* waiting room: READY / START / the countdown overlay are real taps too, so full screen is requested there as well
     (the 15 s countdown itself is not a tap, so it can't ask) */
  hook('lob-ready');hook('lob-start');hook('lob-count');
  /* fit: whenever the viewport changes (entering/leaving full screen, rotation, browser bars), refit every screen to the new size so no gaps remain */
  var fitT=[];
  function refit(){fitT.forEach(clearTimeout);fitT=[0,120,400,900].map(function(d){return setTimeout(function(){
    var de2=document.documentElement;de2.style.setProperty('--vw',innerWidth+'px');de2.style.setProperty('--vh',innerHeight+'px');
    window.dispatchEvent(new Event('resize'))},d)})}
  ['fullscreenchange','webkitfullscreenchange','MSFullscreenChange'].forEach(function(n){document.addEventListener(n,refit)});
  window.addEventListener('orientationchange',refit);
  if(window.visualViewport) window.visualViewport.addEventListener('resize',function(){var de2=document.documentElement;de2.style.setProperty('--vw',innerWidth+'px');de2.style.setProperty('--vh',innerHeight+'px')});
  /* Leaving full screen while a match is on (Esc, the full-screen button, browser gesture) stops the game and shows the
     pause menu. Tapping RESUME there goes back to full screen and continues the game. */
  ['fullscreenchange','webkitfullscreenchange','MSFullscreenChange'].forEach(function(n){
    document.addEventListener(n,function(){
      if(unloading||isFs()) return;
      try{
        var inMatch=(typeof sim!=='undefined'&&sim)||(typeof net!=='undefined'&&net);
        if(inMatch&&typeof setPause==='function'&&!(typeof snap!=='undefined'&&snap&&snap.w)) setPause(true);
      }catch(e){}
    });
  });
  var rs=document.getElementById('pzr');
  if(rs){
    var goFs=function(){ setOff(false); enter(); };
    ['pointerup','click'].forEach(function(n){ rs.addEventListener(n,goFs,true); });
  }
  window.CSKFullscreen={enter:enter,isFs:isFs,allow:function(){allowed=true;if(!userOff()) enter();}};
  /* Create Room: skip when signed-out/locked or busy (the click will just be rejected) */
  hook('host',function(el){ return !el.disabled&&!el.classList.contains('lob-locked-btn'); });
  /* Join: only when a 5-character room code has been typed */
  hook('join',function(el){
    var rm=document.getElementById('rm');
    return !el.disabled&&rm&&rm.value.replace(/[^A-Za-z0-9]/g,'').length>=5;
  });
})();
