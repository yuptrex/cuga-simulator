/* ============ lan.js — same-Wi-Fi multiplayer, 5-digit room code, no internet / server needed ============
 HOW IT WORKS
  - The Cuga Simulator app gives this page a message channel to the phone's own networking: window.cugaLan
    (see LanBridge.kt / LanCore.java in the simulator). The page never opens sockets itself.
  - HOST taps "Host a game": the phone opens a LAN room and shows a 5-digit code.
  - FRIENDS tap "Join a game" and type the code. The code is simply the host's Wi-Fi address (scrambled), so
    nothing has to be broadcast, looked up on the internet, or pasted: it works on a Wi-Fi with no internet at all,
    or on a phone's hotspot with nothing else connected.
  - After that the game talks exactly like the other online modes: the host runs the real simulation, players
    send inputs, the host sends snapshots. game.js only needs makeNet() to return CSKLan.net (already done).

 Messages with the app are plain text (protocol described at the top of LanCore.java):
   page -> app: 'I' (hello)  'H' (host)  'J\t<code>' (join)  'S\t<to>\t<label>\t<data>' (send)  'L' (lock)  'X' (stop)
   app -> page: 'h\t<code>\t<ip>'  'p\t<id>\t1|0'  'j'  'm\t<from>\t<data>'  'x'  'e\t<reason>'
 Lobby messages (hello / ready / roster / start) are JSON over the same link, ahead of the match.
*/
(function(){
'use strict';
const $=id=>document.getElementById(id);
const jp=s=>{try{return JSON.parse(s)}catch(e){return null}};
const bridge=()=>{const b=window.cugaLan;return b&&typeof b.postMessage==='function'?b:null};
const post=s=>{const b=bridge();if(b)try{b.postMessage(s)}catch(e){}};
const myName=()=>(($('nm')&&$('nm').value)||'Player').trim().slice(0,16)||'Player';

/* ============ LanNet: drop-in for FirebaseNet / CSK_HybridNet (see makeNet() in game.js) ============ */
class LanNet{
 constructor(isHost){this.host=!!isHost;this.onmsg=null;this.resend=0}
 get fast(){return true}                  /* direct Wi-Fi link: game.js raises the input rate and trims buffering */
 get path(){return this.host?'HOST':'LAN'}
 /* Host snapshot interval. game.js checks it on every 16 ms net tick, so 0.012 = a snapshot on EVERY tick (~60 Hz, the
    simulation rate). Up to 4 joiners that is ~0.7 MB/s on the Wi-Fi - nothing for a LAN; bigger rooms fall back to ~30 Hz. */
 get snapDt(){return this.host&&CSKLan._ups()<=4?.012:.028}
 send(m,str){
  const s=str||JSON.stringify(m);
  if(this.host)post('S\t'+(m._to||'')+'\t'+((m.t==='st'||m.t==='in')?'u':'r')+'\t'+s);
  else post('S\t\t'+((m.t==='st'||m.t==='in')?'u':'r')+'\t'+s)}
 close(){}   /* the room itself is closed by CSKLan.stop() */
}

/* ============ small themed UI ============ */
const STYLE=`
#csk-lan{position:fixed;inset:0;z-index:9000;display:flex;align-items:center;justify-content:center;
 background:radial-gradient(120% 120% at 50% 0%,#0b121ae6,#05080bf2);font-family:var(--csk-font-body,sans-serif);
 color:var(--csk-text,#eef3f6);padding:16px;box-sizing:border-box}
#csk-lan[hidden]{display:none}
.lan-card{position:relative;width:min(440px,100%);max-height:96vh;overflow:auto;background:var(--csk-panel,#101923);
 border:1px solid var(--csk-line,#2a3b4c);border-radius:var(--csk-radius-lg,20px);box-shadow:var(--csk-shadow-2,0 20px 50px #000a);
 padding:22px;box-sizing:border-box}
.lan-h{font-family:var(--csk-font-display,sans-serif);font-weight:700;font-size:22px;letter-spacing:.02em;margin:0 0 4px}
.lan-sub{color:var(--csk-text-dim,#8da0ad);font-size:13px;margin:0 0 14px;line-height:1.5}
.lan-row{display:flex;gap:10px;margin:10px 0}
.lan-btn{flex:1;appearance:none;border:1px solid var(--csk-line,#2a3b4c);background:var(--csk-panel-2,#18212c);
 color:var(--csk-text,#eef3f6);font:inherit;font-weight:600;border-radius:var(--csk-radius-md,14px);
 padding:14px 12px;cursor:pointer;text-align:center}
.lan-btn:active{transform:scale(.98)}
.lan-btn.gold{background:linear-gradient(180deg,var(--csk-amber-soft,#ffd067),var(--csk-amber,#ffb02e) 60%,var(--csk-amber-deep,#ff7a1f));
 color:#1a1200;border-color:#0000;box-shadow:var(--csk-glow-amber,0 0 18px #ffb02e55)}
.lan-btn[disabled]{opacity:.45;pointer-events:none}
.lan-x{position:absolute;top:12px;right:12px;width:34px;height:34px;border-radius:50%;border:1px solid var(--csk-line,#2a3b4c);
 background:var(--csk-panel-2,#18212c);color:var(--csk-text,#eef3f6);font-size:16px;cursor:pointer}
.lan-code{font:700 54px/1 var(--csk-font-display,'Rajdhani',sans-serif);letter-spacing:.22em;text-align:center;margin:12px 0 6px;
 padding:14px 0 14px .22em;border-radius:14px;background:var(--csk-ink-2,#0b121a);border:1px solid var(--csk-line,#2a3b4c);
 color:var(--csk-amber-soft,#ffd067);user-select:all}
.lan-in{width:100%;box-sizing:border-box;font:700 44px/1 var(--csk-font-display,'Rajdhani',sans-serif);letter-spacing:.3em;text-align:center;
 padding:14px 0 14px .3em;border-radius:14px;background:var(--csk-ink-2,#0b121a);border:1px solid var(--csk-line,#2a3b4c);
 color:var(--csk-text,#eef3f6);outline:none;margin:12px 0 4px}
.lan-in:focus{border-color:var(--csk-amber,#ffb02e)}
.lan-roster{display:flex;flex-direction:column;gap:8px;margin:12px 0}
.lan-seat{display:flex;align-items:center;gap:10px;background:var(--csk-panel-2,#18212c);border:1px solid var(--csk-line,#2a3b4c);
 border-radius:10px;padding:9px 12px;font-size:13px}
.lan-seat b{font-weight:600;flex:1}
.lan-seat small{color:var(--csk-text-dim,#8da0ad)}
.lan-dot{width:8px;height:8px;border-radius:50%;background:#3c5064}
.lan-dot.up{background:#2ee59d}
.lan-err{color:#ff8a7a;font-size:13px;margin-top:8px;min-height:1em;line-height:1.45}
.lan-note{font-size:12px;color:var(--csk-text-dim,#8da0ad);margin-top:10px;line-height:1.5}
`;
function injectStyle(){if($('csk-lan-style'))return;const s=document.createElement('style');s.id='csk-lan-style';s.textContent=STYLE;document.head.appendChild(s)}
function el(tag,cls,html){const e=document.createElement(tag);if(cls)e.className=cls;if(html!=null)e.textContent=html;return e}
function btn(label,cls,fn){const b=el('button','lan-btn'+(cls?' '+cls:''),label);b.type='button';b.onclick=fn;return b}

const ERR={
 nowifi:'This phone isn\u2019t connected to Wi-Fi. Connect to the same Wi-Fi as your friends (or turn on a hotspot) and try again.',
 badcode:'That code isn\u2019t valid \u2014 it must be exactly 5 digits.',
 unreachable:'Couldn\u2019t reach that room. Check the 5 digits, and that you are on the SAME Wi-Fi as the host (guest / \u201cAP isolation\u201d networks block this).',
 code:'No room with that code on this Wi-Fi. Check the 5 digits with the host.',
 full:'That room is full.',
 started:'That match has already started.',
 port:'A LAN room is already open on this phone. Close it first, then try again.',
 bad:'Couldn\u2019t join that room.'};

const CSKLan={
 host:null,client:null,net:null,active:false,
 _panel:null,_role:'',_code:'',_view:'',_roster:{},_pid:{},_started:false,_ready:0,_ip:'',

 available(){return !!bridge()},
 _ups(){let n=0;for(const id in this._roster)if(this._roster[id].up&&!this._roster[id].host)n++;return n},

 open(){
  injectStyle();
  const b=bridge();
  if(b){b.onmessage=e=>this._native(e.data);post('I')}
  this._panel=this._panel||this._build();
  this._panel.hidden=false;
  this.home()},
 close(){if(this._panel)this._panel.hidden=true},
 stop(){
  post('X');
  this.host=this.client=this.net=null;this.active=false;this._role='';this._code='';this._roster={};this._pid={};
  this._started=false;this._ready=0;this._view=''},

 _build(){
  const wrap=el('div');wrap.id='csk-lan';wrap.hidden=true;
  const card=el('div','lan-card');
  const x=el('button','lan-x','\u2715');x.type='button';x.setAttribute('aria-label','Close');x.onclick=()=>{this.stop();this.close()};
  card.appendChild(x);
  const body=el('div');body.id='lan-body';card.appendChild(body);
  wrap.appendChild(card);document.body.appendChild(wrap);
  return wrap},
 _body(){const b=$('lan-body');b.innerHTML='';return b},

 /* ---------- home ---------- */
 home(){
  this.stop();this._view='home';
  const b=this._body();
  b.appendChild(el('h2','lan-h','LAN Match'));
  b.appendChild(el('p','lan-sub','Play with friends on the same Wi-Fi \u2014 even with no internet. One player hosts and tells everyone a 5-digit code.'));
  const ok=this.available();
  const row=el('div','lan-row');
  const hb=btn('HOST A GAME','gold',()=>this.startHost()),jb=btn('JOIN A GAME','',()=>this.joinScreen());
  if(!ok){hb.disabled=jb.disabled=true}
  row.appendChild(hb);row.appendChild(jb);b.appendChild(row);
  b.appendChild(el('p','lan-note',ok?
   'Everyone must be on the same Wi-Fi (or on the host\u2019s hotspot). If joining fails: turn off \u201cswitch to mobile data when Wi-Fi has no internet\u201d on this phone, and make sure the router\u2019s \u201cAP / client isolation\u201d is off.':
   'LAN matches need the Cuga Simulator app on Android. Open this game from the simulator to use them.'))},

 /* ---------- HOST ---------- */
 startHost(){
  this.stop();this._role='host';this._view='host-wait';
  this._roster={host:{name:myName(),ready:1,up:1,host:1}};
  const b=this._body();
  b.appendChild(el('h2','lan-h','Starting room\u2026'));
  post('H')},
 _hosting(code,ip){
  this._code=code;this._ip=ip;this.active=true;this.net=new LanNet(true);this.host=this.net;
  this._hostLobby()},
 _hostLobby(){
  this._view='host';
  const b=this._body();
  b.appendChild(el('h2','lan-h','Your room code'));
  b.appendChild(el('p','lan-sub','Friends on the same Wi-Fi: LAN Match \u2192 Join a game \u2192 type this code.'));
  b.appendChild(el('div','lan-code',this._code));
  const r=el('div','lan-roster');r.id='lan-roster';b.appendChild(r);
  const row=el('div','lan-row');
  const sb=btn('START MATCH','gold',()=>this._beginMatch());sb.id='lan-start';sb.disabled=true;
  row.appendChild(sb);b.appendChild(row);
  b.appendChild(el('div','lan-err'));
  b.appendChild(el('p','lan-note','Wi-Fi address of this phone: '+this._ip+'. Up to 8 players. The match needs at least one friend, and everyone ticked ready.'));
  this._drawRoster()},
 _drawRoster(){
  const list=$('lan-roster');if(!list)return;
  list.innerHTML='';
  const ids=Object.keys(this._roster);
  for(const id of ids){
   const p=this._roster[id],row=el('div','lan-seat');
   row.appendChild(el('span','lan-dot'+(p.up?' up':'')));
   row.appendChild(el('b',null,p.name+(p.host?' (host)':'')));
   row.appendChild(el('small',null,p.host?'host':(p.up?(p.ready?'ready':'not ready'):'connecting\u2026')));
   list.appendChild(row)}
  const sb=$('lan-start');
  if(sb){const cl=ids.filter(i=>!this._roster[i].host);
   sb.disabled=!(cl.length>=1&&cl.every(i=>this._roster[i].up&&this._roster[i].ready))}},
 _pushRoster(){
  if(this._role!=='host')return;
  const l=Object.keys(this._roster).map(i=>{const p=this._roster[i];return[p.name,p.ready?1:0,p.host?1:0,p.up?1:0]});
  post('S\t\tr\t'+JSON.stringify({t:'roster',l}));
  if(this._view==='host')this._drawRoster()},
 _beginMatch(){
  if(this._role!=='host'||this._started)return;
  this._started=true;
  post('L');                                                   /* no new joiners once it starts */
  post('S\t\tr\t'+JSON.stringify({t:'start',room:this._code}));
  this._enterMatch(true,this._code)},

 /* ---------- JOIN ---------- */
 joinScreen(){
  this.stop();this._role='join';this._view='join';
  const b=this._body();
  b.appendChild(el('h2','lan-h','Join a LAN game'));
  b.appendChild(el('p','lan-sub','Type the 5-digit code shown on the host\u2019s phone.'));
  const inp=document.createElement('input');inp.className='lan-in';inp.type='text';inp.inputMode='numeric';inp.pattern='[0-9]*';
  inp.maxLength=5;inp.placeholder='00000';inp.autocomplete='off';inp.setAttribute('aria-label','Room code');inp.id='lan-code-in';
  b.appendChild(inp);
  const err=el('div','lan-err');err.id='lan-err';b.appendChild(err);
  const go=btn('CONNECT','gold',()=>this._join(inp.value));go.id='lan-go';
  inp.addEventListener('input',()=>{inp.value=inp.value.replace(/\D/g,'').slice(0,5);err.textContent='';go.disabled=inp.value.length!==5;
   if(inp.value.length===5)this._join(inp.value)});
  go.disabled=true;
  const row=el('div','lan-row');row.appendChild(btn('BACK','',()=>this.home()));row.appendChild(go);b.appendChild(row);
  setTimeout(()=>{try{inp.focus()}catch(e){}},50)},
 _join(code){
  code=String(code||'').replace(/\D/g,'');
  const err=$('lan-err'),go=$('lan-go');
  if(code.length!==5){if(err)err.textContent=ERR.badcode;return}
  if(this._view==='joining')return;
  this._view='joining';
  if(err)err.textContent='Connecting\u2026';if(go)go.disabled=true;
  this._code=code;post('J\t'+code)},
 _joined(){
  this._view='client';this.active=true;this.net=new LanNet(false);this.client=this.net;
  post('S\t\tr\t'+JSON.stringify({t:'hello',name:myName()}));
  const b=this._body();
  b.appendChild(el('h2','lan-h','Connected'));
  b.appendChild(el('p','lan-sub','Room '+this._code+'. Tick ready \u2014 the host starts the match.'));
  const r=el('div','lan-roster');r.id='lan-roster';b.appendChild(r);
  const row=el('div','lan-row');
  const rb=btn('READY','gold',()=>{this._ready=this._ready?0:1;rb.textContent=this._ready?'NOT READY':'READY';
   post('S\t\tr\t'+JSON.stringify({t:'ready',v:this._ready}))});
  row.appendChild(rb);b.appendChild(row);
  b.appendChild(el('div','lan-err'))},

 _error(reason){
  const msg=ERR[reason]||ERR.bad;
  if(this._view==='joining'){
   this._view='join';this._body();this.joinScreen();
   const e=$('lan-err');if(e)e.textContent=msg;return}
  if(this._view==='host-wait'){
   const b=this._body();b.appendChild(el('h2','lan-h','Couldn\u2019t start the room'));
   b.appendChild(el('div','lan-err',msg));
   const row=el('div','lan-row');row.appendChild(btn('BACK','',()=>this.home()));b.appendChild(row);return}
  const e=document.querySelector('#csk-lan .lan-err');if(e)e.textContent=msg},

 /* ---------- events from the app ---------- */
 _native(s){
  if(typeof s!=='string'||!s)return;
  const t=s[0];
  if(t==='m'){const i=s.indexOf('\t',2);if(i<0)return;this._msg(s.slice(2,i),s.slice(i+1));return}
  const p=s.split('\t');
  if(t==='h')this._hosting(p[1],p[2]);
  else if(t==='p')this._peer(p[1],p[2]==='1');
  else if(t==='j')this._joined();
  else if(t==='x')this._lost();
  else if(t==='e')this._error(p[1])},

 _peer(id,up){
  if(this._role!=='host')return;
  if(!up){
   delete this._roster[id];
   const pid=this._pid[id];delete this._pid[id];
   if(this._started&&pid&&this.net&&this.net.onmsg)this.net.onmsg({t:'bye',id:pid});     /* drop their player at once */
   this._pushRoster();return}
  /* connected; they appear in the roster when their 'hello' (with the name) arrives */
 },
 _msg(from,data){
  const m=jp(data);if(!m||typeof m!=='object')return;
  if(this._role==='host'){
   if(m.t==='hello'){this._roster[from]={name:String(m.name||'Player').slice(0,16),ready:0,up:1};this._pushRoster();return}
   if(m.t==='ready'){const r=this._roster[from];if(r){r.ready=m.v?1:0;this._pushRoster()}return}
   if(m.t==='in'&&m.id)this._pid[from]=m.id;
   if(this.net&&this.net.onmsg)this.net.onmsg(m);return}
  /* joined player */
  if(m.t==='roster'&&Array.isArray(m.l)){
   this._roster={};m.l.forEach((r,i)=>{this._roster['p'+i]={name:String(r[0]),ready:r[1],host:r[2],up:r[3]!==0}});
   if(this._view==='client')this._drawRoster();return}
  if(m.t==='start'){if(!this._started){this._started=true;this._enterMatch(false,m.room||this._code)}return}
  if(this.net&&this.net.onmsg)this.net.onmsg(m)},
 _lost(){
  if(this._role!=='join')return;
  if(this._started){if(this.net&&this.net.onmsg)this.net.onmsg({t:'gone'});return}    /* in a match: game.js shows "host left" */
  this.active=false;this.net=null;
  const b=this._body();b.appendChild(el('h2','lan-h','Disconnected'));
  b.appendChild(el('p','lan-sub','The host closed the room or the Wi-Fi dropped.'));
  const row=el('div','lan-row');row.appendChild(btn('BACK','gold',()=>this.home()));b.appendChild(row)},

 /* ---------- handoff into the real match (same start() the other modes use) ---------- */
 _enterMatch(isHost,room){
  this.close();
  if(this.net)this.net.resend=1;                                /* host: send the world to everyone right away */
  try{if(typeof start==='function')start(isHost?'host':'join',room||'LAN')}catch(e){}}
};
window.CSKLan=CSKLan;
window.CSKLanNet=LanNet;
})();
