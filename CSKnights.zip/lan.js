/* ============ lan.js — room transport (replaces the old Firebase rooms) ============
 Create Room / Join Room now run on the Cuga Simulator's native same-Wi-Fi channel, window.cugaLan
 (LanBridge.kt / LanCore.java in the simulator). No internet, no Firebase, no server. This file has NO UI of its own:
 lobby.js drives it and draws the waiting room; game.js gets its network object from CSKLan.net (see makeNet()).

 HOW IT WORKS
  - HOST taps Create Room: CSKLan.hostRoom() -> the phone opens a LAN room and reports a 5-digit code.
  - FRIENDS tap Join Room and type that code: CSKLan.joinRoom(code). The code is the host's Wi-Fi address (scrambled),
    so nothing is broadcast and it works on a router with no internet or on one phone's hotspot.
  - Lobby messages (hello / seat / ready / roster / start / kick) and match messages (in / st / wd / bye) are JSON over the
    same link. This file routes lobby messages to CSKLan.h.onLobby and match messages to CSKLan.net.onmsg.

 Messages with the app are plain text (protocol at the top of LanCore.java):
   page -> app: 'I' (hello)  'H' (host)  'J\t<code>' (join)  'S\t<to>\t<label>\t<data>' (send)  'L' (lock)  'X' (stop)
   app -> page: 'h\t<code>\t<ip>'  'p\t<id>\t1|0'  'j'  'm\t<from>\t<data>'  'x'  'e\t<reason>'
   (the app may deliver several lines in one message, separated by '\n')
*/
(function(){
'use strict';
const jp=s=>{try{return JSON.parse(s)}catch(e){return null}};
const bridge=()=>{const b=window.cugaLan;return b&&typeof b.postMessage==='function'?b:null};
const post=s=>{const b=bridge();if(b)try{b.postMessage(s)}catch(e){}};
const LOBBY={hello:1,seat:1,ready:1,roster:1,start:1,kick:1,full:1};

/* ============ LanNet: the network object game.js uses in a match (same interface the old Firebase nets had) ============ */
class LanNet{
 constructor(isHost){this.host=!!isHost;this.onmsg=null;this.resend=0}
 get fast(){return true}                  /* direct Wi-Fi link: game.js raises the input rate and trims buffering */
 get path(){return this.host?'HOST':'LAN'}
 /* Host snapshot interval: 30 Hz for up to 4 joiners, 20 Hz for bigger rooms. Every message crosses the WebView bridge
    (a main-thread task on the phone) and is JSON-parsed by each client, so sending one per 60 Hz tick cost frame time;
    the client interpolates between snapshots, so 30 Hz looks the same. */
 get snapDt(){return this.host&&CSKLan.peers()<=4?1/30:.05}
 /* minimum ms between a joiner's input packets (40 Hz) */
 get inDt(){return 25}
 send(m,str){
  const s=str||JSON.stringify(m),lab=(m.t==='st'||m.t==='in')?'u':'r';
  post('S\t'+(this.host?(m._to||''):'')+'\t'+lab+'\t'+s)}
 close(){}   /* the room itself is closed by CSKLan.stop() */
}

const ERR={
 nowifi:'This phone isn’t connected to Wi-Fi. Connect to the same Wi-Fi as your friends (or turn on a hotspot) and try again.',
 badcode:'That code isn’t valid — it must be exactly 5 digits.',
 unreachable:'Couldn’t reach that room. Check the 5 digits, and that you are on the SAME Wi-Fi as the host (guest / “AP isolation” networks block this).',
 code:'No room with that code on this Wi-Fi. Check the 5 digits with the host.',
 full:'That room is full.',
 started:'That match has already started.',
 port:'A room is already open on this phone. Close it first, then try again.',
 noapp:'Rooms need the Cuga Simulator app on Android (they play over Wi-Fi, no internet). Open this game from the simulator.',
 bad:'Couldn’t join that room.'};

const CSKLan={
 net:null,active:false,inMatch:false,role:'',code:'',ip:'',ERR:ERR,
 /* handlers set by lobby.js: onHosting(code,ip) onJoined() onError(reason) onPeer(nid,up) onLobby(from,msg) onLost() */
 h:{},_ready:false,_peers:{},_pid:{},

 available(){return !!bridge()},
 peers(){let n=0;for(const k in this._peers)n++;return n},

 init(){
  const b=bridge();if(!b||this._ready)return !!b;
  b.onmessage=e=>this._native(e.data);post('I');this._ready=true;return true},

 /* ---------- host / join / stop ---------- */
 hostRoom(){
  if(!this.init())return this.h.onError&&this.h.onError('noapp');
  this.stop(true);this.role='host';post('H')},
 joinRoom(code){
  if(!this.init())return this.h.onError&&this.h.onError('noapp');
  code=String(code||'').replace(/\D/g,'');
  if(code.length!==5)return this.h.onError&&this.h.onError('badcode');
  this.stop(true);this.role='join';this.code=code;post('J\t'+code)},
 lock(){post('L')},
 stop(keepBridge){
  if(this.role||this.active)post('X');
  this.net=null;this.active=false;this.inMatch=false;this.role='';this.code='';this.ip='';this._peers={};this._pid={}},

 /* ---------- sending lobby messages ---------- */
 toAll(m){post('S\t\tr\t'+JSON.stringify(m))},          /* host -> everyone, or client -> host */
 toPeer(nid,m){post('S\t'+nid+'\tr\t'+JSON.stringify(m))}, /* host -> one client */

 /* ---------- events from the app ---------- */
 _native(s){
  if(typeof s!=='string'||!s)return;
  if(s.indexOf('\n')>=0){const a=s.split('\n');for(let i=0;i<a.length;i++)this._native(a[i]);return}   /* the app batches lines */
  const t=s[0];
  if(t==='m'){const i=s.indexOf('\t',2);if(i<0)return;this._msg(s.slice(2,i),s.slice(i+1));return}
  const p=s.split('\t');
  if(t==='h'){this.code=p[1];this.ip=p[2]||'';this.active=true;this.net=new LanNet(true);this.h.onHosting&&this.h.onHosting(p[1],p[2])}
  else if(t==='p'){
   if(this.role!=='host')return;
   if(p[2]==='1')this._peers[p[1]]=1;
   else{
    delete this._peers[p[1]];
    const pid=this._pid[p[1]];delete this._pid[p[1]];
    if(this.inMatch&&pid&&this.net&&this.net.onmsg)this.net.onmsg({t:'bye',id:pid});   /* drop their player at once */
   }
   this.h.onPeer&&this.h.onPeer(p[1],p[2]==='1')}
  else if(t==='j'){this.active=true;this.net=new LanNet(false);this.h.onJoined&&this.h.onJoined()}
  else if(t==='x'){if(this.role==='join'){this.active=false;this.h.onLost&&this.h.onLost()}}
  else if(t==='e')this.h.onError&&this.h.onError(p[1])},
 _msg(from,data){
  const m=jp(data);if(!m||typeof m!=='object')return;
  if(LOBBY[m.t]){this.h.onLobby&&this.h.onLobby(from,m);return}
  if(this.role==='host'&&m.t==='in'&&m.id)this._pid[from]=m.id;
  if(this.net&&this.net.onmsg)this.net.onmsg(m)}
};
window.CSKLan=CSKLan;
window.CSKLanNet=LanNet;
})();
