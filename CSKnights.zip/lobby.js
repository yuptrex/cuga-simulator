/* ============ ROOM LOBBY (LAN) ============
 Purely additive layer, loaded after game.js and lan.js. Create Room / Join Room land here before the match. The match
 itself still starts by calling the game's own start(mode, room); nothing about gameplay or the match protocol is touched.

 Rooms run on the simulator's same-Wi-Fi channel (lan.js) - no Firebase. The HOST holds the roster and is the authority:
  client -> host   {t:'hello',gid,name,photo,dk,uk}  {t:'seat',seat}  {t:'ready',v}
  host -> clients  {t:'roster',l:{<gid>:{name,photo,seat,ready,host}}}  {t:'start'}  {t:'kick'}  {t:'full'}
 Seats: 20 are shown, but only MAXH (8) can ever be occupied - the rest are shown locked. */
(function(){
const $=id=>document.getElementById(id);
const SEATS=20;
const KICK_COOL=120000;   /* a removed player must wait this long before joining that room again */
let mySeat=-1,myReady=0,amHost=0,code='',roster={},countdownT=null,enteredMatch=0,nameT=null,
    nidGid={},gidNid={},kickedUntil={},pending='',pendT=null,sentName='';
const LOAD=()=>window.CSKLoad||{show(){},hide(){},around:f=>f()};

/* Name shown in the lobby = the player's callsign (the permanent in-game name chosen at login) and nothing else.
   The Google display name / Gmail address is never used. Only the Google profile picture is taken from the account. */
function callsign(){
 let n='';
 try{if(window.ARA&&ARA.callsign)n=ARA.callsign()||''}catch(e){}
 if(!n){   /* not locked yet: fall back to the name field, but refuse anything that looks like the Google identity */
  n=(($('nm')&&$('nm').value)||'').trim();
  const a=(window.ARA&&ARA.account&&ARA.account())||null;
  if(n.indexOf('@')>=0)n=''}
 n=n.slice(0,16);
 return n||'Player'}
function myAccount(){
 const a=(window.ARA&&ARA.account&&ARA.account())||null;
 return{uid:a?a.uid:myId,name:callsign(),photo:(a&&a.photo)||''}}

/* ---------- persistent identity (survives reloads) used for the kick lockout ---------- */
function devKey(){
 let k='';try{k=localStorage.getItem('csk-did')||''}catch(e){}
 if(!k){k='d'+Math.random().toString(36).slice(2,10)+Date.now().toString(36);try{localStorage.setItem('csk-did',k)}catch(e){}}
 return k}
function uidKey(){const a=(window.ARA&&ARA.account&&ARA.account())||null;return a&&a.uid?'u'+String(a.uid).replace(/[.#$\[\]\/]/g,'_'):''}
function fmtLeft(ms){const t=Math.max(1,Math.ceil(ms/1000)),m=(t/60)|0,sec=t%60;return m+':'+(sec<10?'0':'')+sec}
/* how long (ms) this player is still locked out of room rc; 0 = free to join */
function kickLeft(rc){
 try{const e=+localStorage.getItem('csk-kick:'+rc)||0;if(e>Date.now())return e-Date.now()}catch(e){}
 return 0}

/* ---------- avatar ---------- */
function initials(n){return String(n||'?').trim().slice(0,1).toUpperCase()||'?'}
function avatarHTML(p){
 if(p.photo)return '<img src="'+p.photo.replace(/"/g,'&quot;')+'" alt="" referrerpolicy="no-referrer">';
 return '<i class="lob-ini">'+initials(p.name)+'</i>'}

/* ---------- rendering ---------- */
/* painted seat frames in the artwork (px in the 1983x793 image): 5 columns x 4 rows, numbered 1-20 */
const SX=[472,689,902,1115,1325],SW=[194,191,190,188,189],SY=[148,279,412,545],SH=[109,111,111,111];
const ICON_LOCK='<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>';
const ICON_CHECK='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
const allReady=()=>{const l=Object.values(roster);return l.length>1&&l.every(p=>p.ready||p.host)}   /* needs at least 2 players */; /* the host's START press is their "ready" */
function render(){
 const wrap=$('lob-seats');if(!wrap)return;
 const occ=Object.keys(roster).length;
 $('lob-cnt').textContent=occ+' / '+MAXH+' PLAYERS';
 const frag=document.createDocumentFragment();
 for(let i=0;i<SEATS;i++){
  const locked=i>=MAXH;
  const pid=Object.keys(roster).find(k=>roster[k].seat===i);
  const p=pid?roster[pid]:null;
  const el=document.createElement('div');
  el.className='lob-seat'+(locked?' lob-locked':p?' lob-filled':' lob-open')+(p&&p.ready?' lob-rdy':'')+(pid===myId?' lob-me':'');
  const c=i%5,r=(i/5)|0;
  el.style.cssText='--x:'+SX[c]+';--y:'+SY[r]+';--w:'+SW[c]+';--h:'+SH[r];
  if(locked){
   el.innerHTML='<div class="lob-veil">'+ICON_LOCK+'</div><div class="lob-pill">LOCKED</div>';
  }else if(p){
   el.innerHTML='<div class="lob-glow"></div><div class="lob-av">'+avatarHTML(p)+'</div>'
    +(p.host?'<div class="lob-host-tag">HOST</div>':'')
    +(p.ready||p.host?'<div class="lob-ck">'+ICON_CHECK+'</div>':'')
    +'<div class="lob-pill">'+escapeHtml(p.name||'Player')+(pid===myId?'<small>(you)</small>':'')+'</div>';
   if(amHost&&pid!==myId&&!countdownT){
    el.classList.add('lob-pick');el.setAttribute('role','button');el.tabIndex=0;
    el.setAttribute('aria-label',(p.name||'Player')+': options');
    el.onclick=e=>{e.stopPropagation();openPop(pid)};
    el.onkeydown=e=>{if(e.key=='Enter'||e.key==' '){e.preventDefault();openPop(pid)}}}
  }else{
   el.innerHTML='<div class="lob-glow"></div><div class="lob-pill">OPEN SEAT</div>';
   el.setAttribute('role','button');el.tabIndex=0;
   el.onclick=()=>takeSeat(i);
   el.onkeydown=e=>{if(e.key=='Enter'||e.key==' '){e.preventDefault();takeSeat(i)}};
  }
  frag.appendChild(el)}
 wrap.innerHTML='';wrap.appendChild(frag);
 if(popPid)placePop();
 /* READY (players) / START (host) share the big gold button */
 const rb=$('lob-ready'),sb=$('lob-start');
 if(rb){
  rb.hidden=amHost;
  const lab=rb.querySelector('.lab');
  rb.disabled=mySeat<0;
  if(lab)lab.textContent=mySeat<0?'PICK A SEAT':(myReady?'NOT READY':'READY UP');
  rb.classList.toggle('on',!!myReady&&mySeat>=0)}
 if(sb){sb.hidden=!amHost;sb.disabled=!allReady()}
 const hint=$('lob-hint');
 if(hint){
  if(amHost)hint.textContent=occ<2?'WAITING FOR PLAYERS':(allReady()?'ALL READY':'WAITING FOR READY');
  else hint.textContent=mySeat<0?'PICK A SEAT':(myReady?'WAITING FOR HOST':'PRESS READY')}}
/* Host taps another player's seat -> small popup with "KICK OUT". Tap anywhere else / Esc to dismiss. */
let popPid='';
function closePop(){popPid='';const o=$('lob-pop');if(o)o.hidden=true}
function openPop(pid){
 if(!amHost||!roster[pid]||pid===myId||countdownT)return;
 sfx&&sfx('ui',{j:0});popPid=pid;placePop()}
function placePop(){
 const o=$('lob-pop');if(!o)return;
 const p=roster[popPid];
 if(!p||!amHost||countdownT){closePop();return}
 const i=p.seat,c=i%5,r=(i/5)|0,cx=SX[c]+SW[c]/2,W=176;
 o.style.cssText='--x:'+Math.round(cx-W/2)+';--y:'+(SY[r]+SH[r]-14)+';--w:'+W+';--h:78';
 $('lob-pop-n').textContent=p.name||'Player';
 o.hidden=false}
function doKick(pid){
 if(!amHost||!roster[pid]||pid===myId||countdownT)return;
 const p=roster[pid],nid=gidNid[pid];
 closePop();
 [p.dk,p.uk].forEach(k=>{if(k)kickedUntil[k]=Date.now()+KICK_COOL});
 if(nid)CSKLan.toPeer(nid,{t:'kick'});
 delete roster[pid];if(nid){delete nidGid[nid];delete gidNid[pid]}
 pushRoster();
 netNote((p.name||'Player')+' was removed from the room.',0)}
/* this client was removed by the host */
function onKicked(){
 const rc=code;
 try{localStorage.setItem('csk-kick:'+rc,String(Date.now()+KICK_COOL))}catch(e){}
 const L=LOAD();L.show();
 detachRoom();hideLobby();
 L.hide();
 netNote('You were removed from room '+rc+' by the host. You can rejoin in '+fmtLeft(KICK_COOL)+'.',1)}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}

/* ---------- LAN wiring ---------- */
const me=()=>{const a=myAccount();return{name:a.name,photo:a.photo||'',dk:devKey(),uk:uidKey()}};
function syncMine(){const r=roster[myId];mySeat=r?r.seat:-1;myReady=r&&r.ready?1:0}
/* host: send the roster to everyone and redraw */
function pushRoster(){
 if(!amHost)return;
 CSKLan.toAll({t:'roster',l:roster});
 syncMine();render()}
function sendHello(){const m=me();sentName=m.name;CSKLan.toAll(Object.assign({t:'hello',gid:myId},m))}
function takeSeat(i){
 if(mySeat===i||i>=MAXH)return;
 if(Object.values(roster).some(p=>p.seat===i))return;
 if(amHost){const r=roster[myId];if(!r)return;r.seat=i;r.ready=0;pushRoster()}
 else CSKLan.toAll({t:'seat',seat:i})}
function toggleReady(){
 if(mySeat<0||amHost)return;
 CSKLan.toAll({t:'ready',v:myReady?0:1})}

/* ----- host side: messages from joiners ----- */
function hostLobby(nid,m){
 if(m.t==='hello'){
  const gid=String(m.gid||'').slice(0,40);if(!gid)return;
  const dk=String(m.dk||''),uk=String(m.uk||'');
  if((dk&&kickedUntil[dk]>Date.now())||(uk&&kickedUntil[uk]>Date.now())){CSKLan.toPeer(nid,{t:'kick'});return}
  const old=roster[gid];
  if(!old&&Object.keys(roster).length>=MAXH){CSKLan.toPeer(nid,{t:'full'});return}
  nidGid[nid]=gid;gidNid[gid]=nid;
  roster[gid]={name:String(m.name||'Player').slice(0,16),photo:/^https?:/.test(m.photo||'')?String(m.photo).slice(0,500):'',
   seat:old?old.seat:-1,ready:old?old.ready:0,host:0,dk:dk,uk:uk};
  pushRoster();return}
 const gid=nidGid[nid],r=gid&&roster[gid];if(!r)return;
 if(m.t==='seat'){
  const i=+m.seat;
  if(!(i>=0&&i<MAXH)||Object.values(roster).some(p=>p.seat===i))return pushRoster();   /* taken: resend so the picker's screen corrects itself */
  r.seat=i;r.ready=0;pushRoster()}
 else if(m.t==='ready'){if(r.seat<0)return;r.ready=m.v?1:0;pushRoster()}}

/* ----- joiner side: messages from the host ----- */
function clientLobby(m){
 if(m.t==='roster'&&m.l&&typeof m.l==='object'){
  const had=!!roster[myId];
  roster=m.l;syncMine();
  if(had&&!roster[myId]&&!enteredMatch&&!countdownT)return;   /* removal is announced by 'kick' */
  render();return}
 if(m.t==='start'){if(!countdownT&&!enteredMatch)beginCountdown();return}
 if(m.t==='kick'){if(!enteredMatch)onKicked();return}
 if(m.t==='full'){const L=LOAD();L.show();detachRoom();hideLobby();L.hide();netNote('Room is full ('+MAXH+' players).',1)}}

function onLobbyMsg(from,m){if(amHost)hostLobby(from,m);else clientLobby(m)}
function onPeer(nid,up){
 if(!amHost||up)return;
 const gid=nidGid[nid];delete nidGid[nid];
 if(gid){delete gidNid[gid];if(roster[gid]){delete roster[gid];pushRoster()}}}
function onLost(){
 if(amHost)return;
 if(enteredMatch){if(CSKLan.net&&CSKLan.net.onmsg)CSKLan.net.onmsg({t:'gone'});return}   /* in a match: game.js shows "host left" */
 const L=LOAD();L.show();detachRoom();hideLobby();L.hide();netNote('The host left the room.',1)}

function startNameWatch(){
 clearInterval(nameT);
 nameT=setInterval(()=>{   /* callsign can finish loading after we sat down */
  const n=callsign();
  if(amHost){const r=roster[myId];if(r&&r.name!==n){r.name=n;pushRoster()}}
  else if(CSKLan.active&&sentName&&sentName!==n)sendHello()},1200)}

function attachRoom(roomCode,isHost){
 code=roomCode;amHost=!!isHost;enteredMatch=0;roster={};kickedUntil={};nidGid={};gidNid={};
 if(amHost){const m=me();roster[myId]={name:m.name,photo:m.photo,seat:0,ready:0,host:1,dk:m.dk,uk:m.uk}}
 else sendHello();
 syncMine();startNameWatch();showLobby()}

function detachRoom(){
 clearInterval(nameT);nameT=null;closePop();
 try{CSKLan.stop()}catch(e){}   /* host leaving closes the room for everyone (their link drops); a joiner just disconnects */
 roster={};nidGid={};gidNid={};mySeat=-1;myReady=0;amHost=0;code='';sentName='';
 clearInterval(countdownT);countdownT=null;
 const cnt=$('lob-count');if(cnt)cnt.hidden=true}

/* ---------- show / hide ---------- */
function showLobby(){
 const lob=$('lob');if(!lob)return;
 lob.hidden=false;
 const codeEl=$('lob-code');if(codeEl)codeEl.querySelector('b').textContent=code;
 render()}
function hideLobby(){const lob=$('lob');if(lob)lob.hidden=true}

/* ---------- countdown + handoff to the real match ---------- */
function beginCountdown(){
 setTimeout(render,0);   /* drops the host's kick buttons: nobody can be removed once the countdown is running */
 const cnt=$('lob-count'),n=$('lob-count-n');
 if(!cnt||!n)return;
 cnt.hidden=false;
 const fh=$('lob-count-fs');if(fh)fh.hidden=!!(window.CSKFullscreen&&CSKFullscreen.isFs());
 let left=15;n.textContent=left;closePop();
 clearInterval(countdownT);
 countdownT=setInterval(()=>{
  left--;
  if(left<=0){clearInterval(countdownT);countdownT=null;enterMatch();return}
  n.textContent=left},1000)}
function enterMatch(){
 if(enteredMatch)return;enteredMatch=1;
 const L=LOAD(),host=amHost,rc=code;
 L.show();
 try{window.CSKFullscreen&&CSKFullscreen.enter()}catch(e){}   /* works if the browser still counts a recent tap; READY/START already asked */
 clearInterval(nameT);nameT=null;
 CSKLan.inMatch=true;
 if(CSKLan.net)CSKLan.net.resend=1;   /* host: send the world to everyone right away */
 /* give the loader one frame to paint before the match boots, then reveal the match underneath it */
 setTimeout(()=>{
  hideLobby();
  const cnt=$('lob-count');if(cnt)cnt.hidden=true;
  try{start(host?'host':'join',rc)}finally{L.hide()}},120)}

/* ---------- login gate + wiring the home buttons ---------- */
function requireLogin(){
 if(window.ARA&&ARA.hint())return true;
 netNote('Waiting for your simulator account…',1);
 return false}

function goOnlineLobby(mode){
 audioInit();
 const L=LOAD();
 const busyUI=b=>{$('host').disabled=b;$('join').disabled=b};
 const fail=e=>{clearTimeout(pendT);pending='';busyUI(0);L.hide({fast:1});try{CSKLan.stop()}catch(x){}netNote(CSKLan.ERR[e]||(typeof e=='string'?e:CSKLan.ERR.bad),1)};
 if(!CSKLan.available())return netNote(CSKLan.ERR.noapp,1);
 if(mode=='host'){
  if(!requireLogin())return;
  window.CSK_ROOM_NAME='';
  L.show();busyUI(1);$('msg').textContent='';pending='host';
  clearTimeout(pendT);pendT=setTimeout(()=>fail('port'),9000);
  CSKLan.hostRoom();
  return}
 const rc=String($('rm').value||'').replace(/\D/g,'').slice(0,5);
 if(rc.length!==5){netNote('Enter the 5-digit room code from the host.',1);$('rm').focus();return}
 const left=kickLeft(rc);
 if(left>0)return netNote('The host removed you from room '+rc+'. You can rejoin in '+fmtLeft(left)+'.',1);
 L.show();busyUI(1);pending='join';
 clearTimeout(pendT);pendT=setTimeout(()=>fail('unreachable'),12000);
 CSKLan.joinRoom(rc)}

function leaveLobby(){
 const L=LOAD();L.show();
 detachRoom();hideLobby();
 $('msg').textContent='';
 L.hide()}

function syncHostLock(){
 const h=$('host'),acc=$('acc');if(!h||!acc)return;
 const signed=acc.dataset.s==='in';
 h.classList.toggle('lob-locked-btn',!signed);
 h.title=signed?'':'Sign in with Google to create a room'}

function wire(){
 const L0=LOAD(),done=()=>{clearTimeout(pendT);pending='';$('host').disabled=false;$('join').disabled=false};
 CSKLan.h={
  onHosting(c){if(pending!=='host')return;done();attachRoom(c,true);L0.hide()},
  onJoined(){if(pending!=='join')return;done();attachRoom(CSKLan.code,false);L0.hide()},
  onError(r){
   if(pending){const p=pending;done();L0.hide({fast:1});try{CSKLan.stop()}catch(x){}netNote(CSKLan.ERR[r]||CSKLan.ERR.bad,1);return}
   if(code&&!enteredMatch)netNote(CSKLan.ERR[r]||CSKLan.ERR.bad,1)},
  onPeer:onPeer,onLobby:onLobbyMsg,onLost:onLost};
 const h=$('host'),j=$('join');
 if(h)h.onclick=()=>goOnlineLobby('host');
 if(j)j.onclick=()=>goOnlineLobby('join');
 const acc=$('acc');
 if(acc&&window.MutationObserver){
  new MutationObserver(syncHostLock).observe(acc,{attributes:true,attributeFilter:['data-s']});
  syncHostLock()}
 /* Play Solo: game.js handles the click itself; we only put the loading screen over the switch (capture phase = runs first) */
 const so=$('solo');if(so)so.addEventListener('click',()=>{const L=LOAD();L.show();setTimeout(()=>L.hide(),60)},true);
 const pk=$('lob-pop-kick');if(pk)pk.onclick=e=>{e.stopPropagation();doKick(popPid)};
 document.addEventListener('pointerdown',e=>{if(popPid&&!e.target.closest('#lob-pop,.lob-pick'))closePop()},true);
 document.addEventListener('keydown',e=>{if(e.key=='Escape'&&popPid)closePop()});
 const lv=$('lob-leave');if(lv)lv.onclick=()=>{sfx&&sfx('ui',{j:0});leaveLobby()};
 const rb=$('lob-ready');if(rb)rb.onclick=()=>{sfx&&sfx('ui',{j:0});toggleReady()};
 const sb=$('lob-start');if(sb)sb.onclick=()=>{if(sb.disabled)return;sfx&&sfx('ui',{j:0});if(!amHost||countdownT)return;CSKLan.lock();CSKLan.toAll({t:'start'});beginCountdown()};
 const ce=$('lob-code');if(ce)ce.onclick=()=>{
  try{navigator.clipboard.writeText(code)}catch(e){}};
}
if(document.readyState=='loading')document.addEventListener('DOMContentLoaded',wire);else wire();
})();
