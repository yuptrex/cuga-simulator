/* ============ SIMULATOR ACCOUNT BRIDGE ============
   The simulator app already has its own login. This game never shows a login screen:
   it takes the player straight from the simulator's logged-in account.

   The simulator can hand the account over in ANY ONE of these ways (checked in this order; an old/cached account is never reused, and the account is re-checked every time the game is shown):
     1. window.SIM_USER = {uid, name, photo, token}            (set before the game scripts run, e.g. injected JS)
     2. URL query:  index.html?uid=...&name=...&photo=...&token=...
     3. window.SimulatorBridge.getUser()  -> object or JSON string (native WebView bridge)
     4. postMessage from the parent/opener window:
          {type:'sim-user', user:{uid,name,photo,token}}   (the game also asks with {type:'csk-request-user'})
     5. An existing Firebase Auth session (simulator and game on the same origin + same Firebase project)

   uid   = required, the simulator account's Firebase uid (used for ranks, stats, leaderboard, saved layout)
   name  = the player's NICKNAME as set inside the simulator (send it as `nickname`; never the Gmail/Google name)
   photo = optional avatar URL
   token = optional Firebase *custom token* minted for that same uid. If given, the game signs in to Firebase
           with it so the database rules (auth.uid === uid) accept all saves. */
(function(){
'use strict';
var waiters=[],user=null,tried=false;
function clean(u){
 if(!u||typeof u==='string'){try{u=JSON.parse(u)}catch(e){return null}}
 if(!u||typeof u!=='object')return null;
 var uid=String(u.uid||u.id||u.userId||'').trim();if(!uid)return null;
 return{uid:uid,name:String(u.nickname||u.nickName||u.nick||u.userName||u.username||u.playerName||u.gameName||u.callsign||u.name||'').trim(),photo:String(u.photo||u.photoURL||u.avatar||u.picture||'').trim(),token:String(u.token||u.customToken||'').trim()}}
function give(u){u=clean(u);if(!u)return false;
 if(user){if(user.uid!==u.uid||(u.name&&u.name!==user.name))location.reload();return true}
 user=u;
 var w=waiters;waiters=[];w.forEach(function(f){try{f(user)}catch(e){}});return true}
function fromUrl(){try{var q=new URLSearchParams(location.search),o={uid:q.get('uid'),nickname:q.get('nickname')||q.get('nick')||q.get('username'),name:q.get('name'),photo:q.get('photo'),token:q.get('token')};
 if(o.uid)return o;}catch(e){}return null}
function fromNative(){try{var b=window.SimulatorBridge;if(b&&typeof b.getUser==='function')return b.getUser()}catch(e){}return null}
function fromFirebase(){return new Promise(function(res){var n=0,iv=setInterval(function(){n++;
 try{if(window.firebase&&firebase.apps&&firebase.apps.length&&firebase.auth){clearInterval(iv);
  var off=firebase.auth().onAuthStateChanged(function(u){off();res(u&&!u.isAnonymous?{uid:u.uid,name:'',photo:u.photoURL}:null)});return}}catch(e){}
 if(n>20){clearInterval(iv);res(null)}},150)})}
window.addEventListener('message',function(e){var d=e.data;if(typeof d==='string'){try{d=JSON.parse(d)}catch(x){return}}
 if(d&&(d.type==='sim-user'||d.type==='simulator-user'))give(d.user||d)});
function ask(){try{var m={type:'csk-request-user'};if(window.parent&&window.parent!==window)window.parent.postMessage(m,'*');if(window.opener)window.opener.postMessage(m,'*')}catch(e){}}
function find(){if(tried)return;tried=true;
 if(give(window.SIM_USER)||give(fromUrl())||give(fromNative()))return;
 ask();
 setTimeout(function(){if(user)return;
  fromFirebase().then(function(u){if(!user&&u)give(u)})},400)}
window.CSKSim={
 /* resolves with the simulator user, or null after `ms` if there is none (the game then runs as a guest) */
 get:function(ms){return new Promise(function(res){if(user)return res(user);var t=setTimeout(function(){res(user)},ms||8000);
  waiters.push(function(u){clearTimeout(t);res(u)});find()})},
 set:give,user:function(){return user}};
/* re-check the simulator's CURRENT account every time the game comes back to the screen */
function recheck(){if(!user)return;if(give(window.SIM_USER)||give(fromNative()))return;ask()}
document.addEventListener('visibilitychange',function(){if(!document.hidden)recheck()});
window.addEventListener('focus',recheck);window.addEventListener('pageshow',recheck);
try{localStorage.removeItem('sim-user')}catch(e){}   /* forget any account cached by older builds */
window.CSK_AUTHED=1;   /* no sign-in step, so fullscreen etc. are allowed straight away */
find();
})();
